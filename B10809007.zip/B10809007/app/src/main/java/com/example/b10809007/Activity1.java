package com.example.b10809007;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

//程式碼參考b10809001改寫
public class Activity1 extends AppCompatActivity implements Fragment1.ScanInterface {

    BluetoothLeScanner bluetoothLeScanner;
    BluetoothAdapter bluetoothAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
    }

    @Override
    public void search(Adapter1 adapter1, boolean scanBool) {
        if(bluetoothAdapter != null){
            Log.d("Logdd", "BlueTooth Adapter is not null");
        }
        ScanCallback scanCallback = new ScanCallback() {

            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                Log.d("logdd","scancallback");
                super.onScanResult(callbackType, result);
                adapter1.setArrayList(result.getScanRecord().toString());
            }
        };
        if(scanBool == true){
            Log.d("logdd","scancallback1");
            bluetoothLeScanner.startScan(scanCallback);


        }
        else {
            Log.d("logdd","scancallback0");
            bluetoothLeScanner.stopScan(scanCallback);

        }
    }
}