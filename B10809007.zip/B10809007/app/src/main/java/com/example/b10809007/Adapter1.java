package com.example.b10809007;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//程式碼參考b10809001改寫
public class Adapter1 extends RecyclerView.Adapter<Adapter1.ViewHolder1> {
    interface OnClickListener{
        void onClick(String s);
    }
    OnClickListener onClickListener;
    ArrayList<String> arrayList = new ArrayList<>();
    public void setArrayList(String s){
        arrayList.add(s);
        notifyDataSetChanged();
    }

    public Adapter1(OnClickListener onClickListener){
        this.onClickListener = onClickListener;
    }
    @NonNull
    @Override
    public ViewHolder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new ViewHolder1(view, onClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder1 holder, int position) {
        holder.textView.setText(arrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder1 extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView;
        OnClickListener onClickListener;
        public ViewHolder1(@NonNull View itemView, OnClickListener onClickListener) {
            super(itemView);
            textView = itemView.findViewById(R.id.list_item_tv);
            this.onClickListener = onClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onClickListener.onClick(arrayList.get(getAdapterPosition()));
        }
    }

}
